# skin.osmc

DylanMas' OSMC Skin.

The default skin for OSMC, but with bigger text!
It's intended to be small-screen friendly. All text in the skin is big enough to be readable.
This was tested on a 2.2" ILI9341 320x240 TFT LCD.

INFO ABOUT THE ORIGINAL SKIN (NON-MODIFIED)______________________________________________________________________________,
                                                                                                                         |
For further information about the original skin, check out OSMC's wiki here: https://osmc.tv/wiki/general/the-osmc-skin/ |
                                                                                                                         |
## The original skin is shipped with official releases of OSMC (https://osmc.tv/download/).                              |
                                                                                                                         |
Original skin: Andy Morton (https://github.com/BobCratchett)                                                             |
                                                                                                                         |
Original design: Simon Brunton (https://simonbrunton.com/)                                                               |
                                                                                                                         |
Original Skinner: Julian Michel (https://github.com/Ch1llb0/skin.osmc)                                                   |
                                                                                                                         |
========================================================================================================================='
